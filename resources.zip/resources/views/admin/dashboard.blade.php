@extends('admin.layouts.app')

@section('content')
    <!-- partial -->

    <div class="page-wrapper">

        <div class="page-content">

            <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
                <div>
                    <h4 class="mb-3 mb-md-0">Welcome to {{config('app.name')}} Dashboard</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-12 col-xl-12 stretch-card">
                    <div class="row flex-grow-1">
                        @if($admins)

                        @if($admins->permission == 'Superadmin')
                        <div class="col-md-4 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-baseline">
                                        <h6 class="card-title mb-0">Daily Income</h6>
                                    </div>
                                    <div class="row">
                                        <div class="col-6 col-md-12 col-xl-5">
                                            <h3 class="mb-2">{{ $daily }}</h3>
                                            @php
                                                $now = \Illuminate\Support\Carbon::now();
                                                $previousDayPrice = \Illuminate\Support\Facades\DB::table('orders')
                                                                    ->whereDate('created_at', '<', $now)
                                                                    ->where('order_status','Delivered')
                                                                    ->orderBy('created_at', 'desc')
                                                                    ->value('price');

                                                if ($previousDayPrice != 0) {
                                                    $percentageChange = (($daily - $previousDayPrice) / $previousDayPrice) * 100;
                                                } else {
                                                    $percentageChange = 0;
                                                }

                                                // Determine if it's positive or negative change
                                                $changeClass = $percentageChange > 0 ? 'text-success' : ($percentageChange < 0 ? 'text-danger' : '');

                                                // Arrow icon
                                                $arrowIcon = $percentageChange > 0 ? 'arrow-up' : 'arrow-down';
                                            @endphp

                                            <div class="d-flex align-items-baseline">
                                                <p class="{{ $changeClass }}">
                                                    <span>{{ number_format($percentageChange, 2) }}%</span>
                                                    <i data-feather="{{ $arrowIcon }}" class="icon-sm mb-1"></i>
                                                </p>
                                            </div>
                                        </div>

                                        <div class="col-6 col-md-12 col-xl-7">
                                            <div id="customersCharts" class="mt-md-3 mt-xl-0"
                                                 data-daily="{{ $daily }}"
                                                 data-percentage-change="{{ $percentageChange }}"></div>
                                        </div>





                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-baseline">
                                        <h6 class="card-title mb-0">Monthly Income</h6>
                                    </div>
                                    <div class="row">
                                        <div class="col-6 col-md-12 col-xl-5">
                                            <h3 class="mb-2">{{ $month }}</h3>
                                            @php
                                                // Calculate percentage change for the month
                                                $previousMonthTotal = \Illuminate\Support\Facades\DB::table('orders')
                                                                        ->whereYear('created_at', now()->year)
                                                                        ->whereMonth('created_at', now()->subMonth()->month)
                                                                        ->where('order_status','Delivered')
                                                                        ->sum('price');

                                                $currentMonthTotal = \Illuminate\Support\Facades\DB::table('orders')
                                                                        ->whereYear('created_at', now()->year)
                                                                        ->whereMonth('created_at', now()->month)
                                                                        ->where('order_status','Delivered')
                                                                        ->sum('price');

                                                if ($previousMonthTotal != 0) {
                                                    $percentageChange = (($currentMonthTotal - $previousMonthTotal) / $previousMonthTotal) * 100;
                                                } else {
                                                    $percentageChange = 0;
                                                }

                                                // Determine if it's positive or negative change
                                                $changeClass = $percentageChange > 0 ? 'text-success' : ($percentageChange < 0 ? 'text-danger' : '');

                                                // Arrow icon
                                                $arrowIcon = $percentageChange > 0 ? 'arrow-up' : 'arrow-down';
                                            @endphp

                                            <div class="d-flex align-items-baseline">
                                                <p class="{{ $changeClass }}">
                                                    <span>{{ number_format(abs($percentageChange), 1) }}%</span> <!-- Absolute value for display -->
                                                    <i data-feather="{{ $arrowIcon }}" class="icon-sm mb-1"></i>
                                                </p>
                                            </div>
                                        </div>

{{--                                        <div class="col-6 col-md-12 col-xl-7">--}}
{{--                                            <div id="ordersChart" class="mt-md-3 mt-xl-0"></div>--}}
{{--                                        </div>--}}
                                    </div>
                                </div>
                            </div>
                        </div>
                            @endif
{{--                        --}}

                        <!-- Section 2, 1st row -->
                        <div class="col-md-4 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-baseline">
                                        <h6 class="card-title mb-0">Processing Orders</h6>
                                    </div>
                                    <div class="row">
                                        <div class="col-6 col-md-12 col-xl-5">
                                            <h3 class="mb-2">{{$processing}}</h3>
                                            <div class="d-flex align-items-baseline">
                                                <p class="text-success">
                                                    <span></span>
{{--                                                    <i data-feather="arrow-up" class="icon-sm mb-1"></i>--}}
                                                </p>
                                            </div>
                                        </div>
{{--                                        <div class="col-6 col-md-12 col-xl-7">--}}
{{--                                            <div id="growthChart" class="mt-md-3 mt-xl-0"></div>--}}
{{--                                        </div>--}}
                                    </div>
                                </div>
                            </div>
                        </div>


                        <!-- Section 2, 2nd row -->
                        <div class="col-md-4 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-baseline">
                                        <h6 class="card-title mb-0">Shipping Orders</h6>
{{--                                        <div class="dropdown mb-2">--}}
{{--                                            <a type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-haspopup="true"--}}
{{--                                               aria-expanded="false">--}}
{{--                                                <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>--}}
{{--                                            </a>--}}
{{--                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton2">--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"--}}
{{--                                                                                                                          class="icon-sm me-2"></i> <span class="">View</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
{{--                                                        data-feather="edit-2" class="icon-sm me-2"></i> <span class="">Edit</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"--}}
{{--                                                                                                                          class="icon-sm me-2"></i> <span class="">Delete</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
{{--                                                        data-feather="printer" class="icon-sm me-2"></i> <span class="">Print</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
{{--                                                        data-feather="download" class="icon-sm me-2"></i> <span class="">Download</span></a>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
                                    </div>
                                    <div class="row">
                                        <div class="col-6 col-md-12 col-xl-5">
                                            <h3 class="mb-2">{{$shipping}}</h3>
                                            <div class="d-flex align-items-baseline">
                                                <p class="text-success">
                                                    <span></span>
{{--                                                    <i data-feather="arrow-up" class="icon-sm mb-1"></i>--}}
                                                </p>
                                            </div>
                                        </div>
{{--                                        <div class="col-6 col-md-12 col-xl-7">--}}
{{--                                            <div id="growthChart" class="mt-md-3 mt-xl-0"></div>--}}
{{--                                        </div>--}}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Section 2, 2nd row -->
                        <div class="col-md-4 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-baseline">
                                        <h6 class="card-title mb-0">Delivery Orders</h6>
{{--                                        <div class="dropdown mb-2">--}}
{{--                                            <a type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-haspopup="true"--}}
{{--                                               aria-expanded="false">--}}
{{--                                                <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>--}}
{{--                                            </a>--}}
{{--                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton2">--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"--}}
{{--                                                                                                                          class="icon-sm me-2"></i> <span class="">View</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
{{--                                                        data-feather="edit-2" class="icon-sm me-2"></i> <span class="">Edit</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"--}}
{{--                                                                                                                          class="icon-sm me-2"></i> <span class="">Delete</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
{{--                                                        data-feather="printer" class="icon-sm me-2"></i> <span class="">Print</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
{{--                                                        data-feather="download" class="icon-sm me-2"></i> <span class="">Download</span></a>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
                                    </div>
                                    <div class="row">
                                        <div class="col-6 col-md-12 col-xl-5">
                                            <h3 class="mb-2">{{$delivered}}</h3>
                                            <div class="d-flex align-items-baseline">
                                                <p class="text-success">
                                                    <span></span>
{{--                                                    <i data-feather="arrow-up" class="icon-sm mb-1"></i>--}}
                                                </p>
                                            </div>
                                        </div>
{{--                                        <div class="col-6 col-md-12 col-xl-7">--}}
{{--                                            <div id="growthChart" class="mt-md-3 mt-xl-0"></div>--}}
{{--                                        </div>--}}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end section 2 -->
                        <!-- Section 3, 1st position -->
                        <div class="col-md-4 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-baseline">
                                        <h6 class="card-title mb-0">Total Customer</h6>
{{--                                        <div class="dropdown mb-2">--}}
{{--                                            <a type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-haspopup="true"--}}
{{--                                               aria-expanded="false">--}}
{{--                                                <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>--}}
{{--                                            </a>--}}
{{--                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton2">--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"--}}
{{--                                                                                                                          class="icon-sm me-2"></i> <span class="">View</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
{{--                                                        data-feather="edit-2" class="icon-sm me-2"></i> <span class="">Edit</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"--}}
{{--                                                                                                                          class="icon-sm me-2"></i> <span class="">Delete</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
{{--                                                        data-feather="printer" class="icon-sm me-2"></i> <span class="">Print</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
{{--                                                        data-feather="download" class="icon-sm me-2"></i> <span class="">Download</span></a>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
                                    </div>
                                    <div class="row">
                                        <div class="col-6 col-md-12 col-xl-5">
                                            <h3 class="mb-2">{{ $currentPeriodCount }}</h3>
                                            @php
                                                // Determine the text class and arrow icon
                                                $changeClass = $isIncrease ? 'text-success' : 'text-danger';
                                                $arrowIcon = $isIncrease ? 'arrow-up' : 'arrow-down';
                                            @endphp

                                            <div class="d-flex align-items-baseline">
                                                <p class="{{ $changeClass }}">
                                                    <span>{{ $isIncrease ? '+' : '' }}{{ $change }}</span>
                                                    <i data-feather="{{ $arrowIcon }}" class="icon-sm mb-1"></i>
                                                </p>
                                            </div>
                                        </div>

                                        <script>
                                            document.addEventListener('DOMContentLoaded', function() {
                                                if (window.feather) {
                                                    window.feather.replace();
                                                }
                                            });
                                        </script>

                                        {{--                                        <div class="col-6 col-md-12 col-xl-7">--}}
{{--                                            <div id="growthChart" class="mt-md-3 mt-xl-0"></div>--}}
{{--                                        </div>--}}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Section 3, 2nd position -->
                        <div class="col-md-4 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-baseline">
                                        <h6 class="card-title mb-0">Depo Information</h6>
{{--                                        <div class="dropdown mb-2">--}}
{{--                                            <a type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-haspopup="true"--}}
{{--                                               aria-expanded="false">--}}
{{--                                                <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>--}}
{{--                                            </a>--}}
{{--                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton2">--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"--}}
{{--                                                                                                                          class="icon-sm me-2"></i> <span class="">View</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
{{--                                                        data-feather="edit-2" class="icon-sm me-2"></i> <span class="">Edit</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"--}}
{{--                                                                                                                          class="icon-sm me-2"></i> <span class="">Delete</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
{{--                                                        data-feather="printer" class="icon-sm me-2"></i> <span class="">Print</span></a>--}}
{{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
{{--                                                        data-feather="download" class="icon-sm me-2"></i> <span class="">Download</span></a>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
                                    </div>
                                    <div class="row">
                                        <div class="col-6 col-md-12 col-xl-5">
                                            <h3 class="mb-2">{{ $depocurrentPeriodCount }}</h3>
                                            @php
                                                // Determine the text class and arrow icon
                                                $depochangeClass = $depoisIncrease ? 'text-success' : 'text-danger';
                                                $depoarrowIcon = $depoisIncrease ? 'arrow-up' : 'arrow-down';
                                            @endphp

                                            <div class="d-flex align-items-baseline">
                                                <p class="{{ $depochangeClass }}">
                                                    <span>{{ $depoisIncrease ? '+' : '' }}{{ $depochange }}</span>
                                                    <i data-feather="{{ $depoarrowIcon }}" class="icon-sm mb-1"></i>
                                                </p>
                                            </div>
                                        </div>

                                        <script>
                                            document.addEventListener('DOMContentLoaded', function() {
                                                if (window.feather) {
                                                    window.feather.replace();
                                                }
                                            });
                                        </script>
{{--                                        <div class="col-6 col-md-12 col-xl-7">--}}
{{--                                            <div id="growthChart" class="mt-md-3 mt-xl-0"></div>--}}
{{--                                        </div>--}}
                                    </div>
                                </div>
                            </div>
                        </div>
                        @else

                            <div class="col-md-4 grid-margin stretch-card">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-baseline">
                                            <h6 class="card-title mb-0">Daily Income</h6>
                                        </div>
                                        <div class="row">
                                            <div class="col-6 col-md-12 col-xl-5">
                                                <h3 class="mb-2">{{ $daily }}</h3>
                                                @php
                                                    $now = \Illuminate\Support\Carbon::now();
                                                    $previousDayPrice = \Illuminate\Support\Facades\DB::table('orders')
                                                                        ->whereDate('created_at', '<', $now)
                                                                        ->where('order_status','Delivered')
                                                                        ->orderBy('created_at', 'desc')
                                                                        ->value('price');

                                                    if ($previousDayPrice != 0) {
                                                        $percentageChange = (($daily - $previousDayPrice) / $previousDayPrice) * 100;
                                                    } else {
                                                        $percentageChange = 0;
                                                    }

                                                    // Determine if it's positive or negative change
                                                    $changeClass = $percentageChange > 0 ? 'text-success' : ($percentageChange < 0 ? 'text-danger' : '');

                                                    // Arrow icon
                                                    $arrowIcon = $percentageChange > 0 ? 'arrow-up' : 'arrow-down';
                                                @endphp

                                                <div class="d-flex align-items-baseline">
                                                    <p class="{{ $changeClass }}">
                                                        <span>{{ number_format($percentageChange, 2) }}%</span>
                                                        <i data-feather="{{ $arrowIcon }}" class="icon-sm mb-1"></i>
                                                    </p>
                                                </div>
                                            </div>

                                            <div class="col-6 col-md-12 col-xl-7">
                                                <div id="customersCharts" class="mt-md-3 mt-xl-0"
                                                     data-daily="{{ $daily }}"
                                                     data-percentage-change="{{ $percentageChange }}"></div>
                                            </div>





                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 grid-margin stretch-card">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-baseline">
                                            <h6 class="card-title mb-0">Monthly Income</h6>
                                            {{--                                        <div class="dropdown mb-2">--}}
                                            {{--                                            <a type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-haspopup="true"--}}
                                            {{--                                               aria-expanded="false">--}}
                                            {{--                                                <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>--}}
                                            {{--                                            </a>--}}
                                            {{--                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton1">--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"--}}
                                            {{--                                                                                                                          class="icon-sm me-2"></i> <span class="">View</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="edit-2" class="icon-sm me-2"></i> <span class="">Edit</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"--}}
                                            {{--                                                                                                                          class="icon-sm me-2"></i> <span class="">Delete</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="printer" class="icon-sm me-2"></i> <span class="">Print</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="download" class="icon-sm me-2"></i> <span class="">Download</span></a>--}}
                                            {{--                                            </div>--}}
                                            {{--                                        </div>--}}
                                        </div>
                                        <div class="row">
                                            <div class="col-6 col-md-12 col-xl-5">
                                                <h3 class="mb-2">{{ $month }}</h3>
                                                @php
                                                    // Calculate percentage change for the month
                                                    $previousMonthTotal = \Illuminate\Support\Facades\DB::table('orders')
                                                                            ->whereYear('created_at', now()->year)
                                                                            ->whereMonth('created_at', now()->subMonth()->month)
                                                                            ->where('order_status','Delivered')
                                                                            ->sum('price');

                                                    $currentMonthTotal = \Illuminate\Support\Facades\DB::table('orders')
                                                                            ->whereYear('created_at', now()->year)
                                                                            ->whereMonth('created_at', now()->month)
                                                                            ->where('order_status','Delivered')
                                                                            ->sum('price');

                                                    if ($previousMonthTotal != 0) {
                                                        $percentageChange = (($currentMonthTotal - $previousMonthTotal) / $previousMonthTotal) * 100;
                                                    } else {
                                                        $percentageChange = 0;
                                                    }

                                                    // Determine if it's positive or negative change
                                                    $changeClass = $percentageChange > 0 ? 'text-success' : ($percentageChange < 0 ? 'text-danger' : '');

                                                    // Arrow icon
                                                    $arrowIcon = $percentageChange > 0 ? 'arrow-up' : 'arrow-down';
                                                @endphp

                                                <div class="d-flex align-items-baseline">
                                                    <p class="{{ $changeClass }}">
                                                        <span>{{ number_format(abs($percentageChange), 1) }}%</span> <!-- Absolute value for display -->
                                                        <i data-feather="{{ $arrowIcon }}" class="icon-sm mb-1"></i>
                                                    </p>
                                                </div>
                                            </div>

                                            {{--                                        <div class="col-6 col-md-12 col-xl-7">--}}
                                            {{--                                            <div id="ordersChart" class="mt-md-3 mt-xl-0"></div>--}}
                                            {{--                                        </div>--}}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{--                        --}}

                            <!-- Section 2, 1st row -->
                            <div class="col-md-4 grid-margin stretch-card">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-baseline">
                                            <h6 class="card-title mb-0">Processing Orders</h6>
                                            {{--                                        <div class="dropdown mb-2">--}}
                                            {{--                                            <a type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-haspopup="true"--}}
                                            {{--                                               aria-expanded="false">--}}
                                            {{--                                                <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>--}}
                                            {{--                                            </a>--}}
                                            {{--                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton2">--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"--}}
                                            {{--                                                                                                                          class="icon-sm me-2"></i> <span class="">View</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="edit-2" class="icon-sm me-2"></i> <span class="">Edit</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"--}}
                                            {{--                                                                                                                          class="icon-sm me-2"></i> <span class="">Delete</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="printer" class="icon-sm me-2"></i> <span class="">Print</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="download" class="icon-sm me-2"></i> <span class="">Download</span></a>--}}
                                            {{--                                            </div>--}}
                                            {{--                                        </div>--}}
                                        </div>
                                        <div class="row">
                                            <div class="col-6 col-md-12 col-xl-5">
                                                <h3 class="mb-2">{{$processing}}</h3>
                                                <div class="d-flex align-items-baseline">
                                                    <p class="text-success">
                                                        <span></span>
                                                        {{--                                                    <i data-feather="arrow-up" class="icon-sm mb-1"></i>--}}
                                                    </p>
                                                </div>
                                            </div>
                                            {{--                                        <div class="col-6 col-md-12 col-xl-7">--}}
                                            {{--                                            <div id="growthChart" class="mt-md-3 mt-xl-0"></div>--}}
                                            {{--                                        </div>--}}
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <!-- Section 2, 2nd row -->
                            <div class="col-md-4 grid-margin stretch-card">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-baseline">
                                            <h6 class="card-title mb-0">Shipping Orders</h6>
                                            {{--                                        <div class="dropdown mb-2">--}}
                                            {{--                                            <a type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-haspopup="true"--}}
                                            {{--                                               aria-expanded="false">--}}
                                            {{--                                                <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>--}}
                                            {{--                                            </a>--}}
                                            {{--                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton2">--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"--}}
                                            {{--                                                                                                                          class="icon-sm me-2"></i> <span class="">View</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="edit-2" class="icon-sm me-2"></i> <span class="">Edit</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"--}}
                                            {{--                                                                                                                          class="icon-sm me-2"></i> <span class="">Delete</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="printer" class="icon-sm me-2"></i> <span class="">Print</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="download" class="icon-sm me-2"></i> <span class="">Download</span></a>--}}
                                            {{--                                            </div>--}}
                                            {{--                                        </div>--}}
                                        </div>
                                        <div class="row">
                                            <div class="col-6 col-md-12 col-xl-5">
                                                <h3 class="mb-2">{{$shipping}}</h3>
                                                <div class="d-flex align-items-baseline">
                                                    <p class="text-success">
                                                        <span></span>
                                                        {{--                                                    <i data-feather="arrow-up" class="icon-sm mb-1"></i>--}}
                                                    </p>
                                                </div>
                                            </div>
                                            {{--                                        <div class="col-6 col-md-12 col-xl-7">--}}
                                            {{--                                            <div id="growthChart" class="mt-md-3 mt-xl-0"></div>--}}
                                            {{--                                        </div>--}}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Section 2, 2nd row -->
                            <div class="col-md-4 grid-margin stretch-card">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-baseline">
                                            <h6 class="card-title mb-0">Delivery Orders</h6>
                                            {{--                                        <div class="dropdown mb-2">--}}
                                            {{--                                            <a type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-haspopup="true"--}}
                                            {{--                                               aria-expanded="false">--}}
                                            {{--                                                <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>--}}
                                            {{--                                            </a>--}}
                                            {{--                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton2">--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"--}}
                                            {{--                                                                                                                          class="icon-sm me-2"></i> <span class="">View</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="edit-2" class="icon-sm me-2"></i> <span class="">Edit</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"--}}
                                            {{--                                                                                                                          class="icon-sm me-2"></i> <span class="">Delete</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="printer" class="icon-sm me-2"></i> <span class="">Print</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="download" class="icon-sm me-2"></i> <span class="">Download</span></a>--}}
                                            {{--                                            </div>--}}
                                            {{--                                        </div>--}}
                                        </div>
                                        <div class="row">
                                            <div class="col-6 col-md-12 col-xl-5">
                                                <h3 class="mb-2">{{$delivered}}</h3>
                                                <div class="d-flex align-items-baseline">
                                                    <p class="text-success">
                                                        <span></span>
                                                        {{--                                                    <i data-feather="arrow-up" class="icon-sm mb-1"></i>--}}
                                                    </p>
                                                </div>
                                            </div>
                                            {{--                                        <div class="col-6 col-md-12 col-xl-7">--}}
                                            {{--                                            <div id="growthChart" class="mt-md-3 mt-xl-0"></div>--}}
                                            {{--                                        </div>--}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end section 2 -->
                            <!-- Section 3, 1st position -->
                            <div class="col-md-4 grid-margin stretch-card">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-baseline">
                                            <h6 class="card-title mb-0">Total Customer</h6>
                                            {{--                                        <div class="dropdown mb-2">--}}
                                            {{--                                            <a type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-haspopup="true"--}}
                                            {{--                                               aria-expanded="false">--}}
                                            {{--                                                <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>--}}
                                            {{--                                            </a>--}}
                                            {{--                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton2">--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"--}}
                                            {{--                                                                                                                          class="icon-sm me-2"></i> <span class="">View</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="edit-2" class="icon-sm me-2"></i> <span class="">Edit</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"--}}
                                            {{--                                                                                                                          class="icon-sm me-2"></i> <span class="">Delete</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="printer" class="icon-sm me-2"></i> <span class="">Print</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="download" class="icon-sm me-2"></i> <span class="">Download</span></a>--}}
                                            {{--                                            </div>--}}
                                            {{--                                        </div>--}}
                                        </div>
                                        <div class="row">
                                            <div class="col-6 col-md-12 col-xl-5">
                                                <h3 class="mb-2">{{ $currentPeriodCount }}</h3>
                                                @php
                                                    // Determine the text class and arrow icon
                                                    $changeClass = $isIncrease ? 'text-success' : 'text-danger';
                                                    $arrowIcon = $isIncrease ? 'arrow-up' : 'arrow-down';
                                                @endphp

                                                <div class="d-flex align-items-baseline">
                                                    <p class="{{ $changeClass }}">
                                                        <span>{{ $isIncrease ? '+' : '' }}{{ $change }}</span>
                                                        <i data-feather="{{ $arrowIcon }}" class="icon-sm mb-1"></i>
                                                    </p>
                                                </div>
                                            </div>

                                            <script>
                                                document.addEventListener('DOMContentLoaded', function() {
                                                    if (window.feather) {
                                                        window.feather.replace();
                                                    }
                                                });
                                            </script>

                                            {{--                                        <div class="col-6 col-md-12 col-xl-7">--}}
                                            {{--                                            <div id="growthChart" class="mt-md-3 mt-xl-0"></div>--}}
                                            {{--                                        </div>--}}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Section 3, 2nd position -->
                            <div class="col-md-4 grid-margin stretch-card">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-baseline">
                                            <h6 class="card-title mb-0">Depo Information</h6>
                                            {{--                                        <div class="dropdown mb-2">--}}
                                            {{--                                            <a type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-haspopup="true"--}}
                                            {{--                                               aria-expanded="false">--}}
                                            {{--                                                <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>--}}
                                            {{--                                            </a>--}}
                                            {{--                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton2">--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"--}}
                                            {{--                                                                                                                          class="icon-sm me-2"></i> <span class="">View</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="edit-2" class="icon-sm me-2"></i> <span class="">Edit</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"--}}
                                            {{--                                                                                                                          class="icon-sm me-2"></i> <span class="">Delete</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="printer" class="icon-sm me-2"></i> <span class="">Print</span></a>--}}
                                            {{--                                                <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i--}}
                                            {{--                                                        data-feather="download" class="icon-sm me-2"></i> <span class="">Download</span></a>--}}
                                            {{--                                            </div>--}}
                                            {{--                                        </div>--}}
                                        </div>
                                        <div class="row">
                                            <div class="col-6 col-md-12 col-xl-5">
                                                <h3 class="mb-2">{{ $depocurrentPeriodCount }}</h3>
                                                @php
                                                    // Determine the text class and arrow icon
                                                    $depochangeClass = $depoisIncrease ? 'text-success' : 'text-danger';
                                                    $depoarrowIcon = $depoisIncrease ? 'arrow-up' : 'arrow-down';
                                                @endphp

                                                <div class="d-flex align-items-baseline">
                                                    <p class="{{ $depochangeClass }}">
                                                        <span>{{ $depoisIncrease ? '+' : '' }}{{ $depochange }}</span>
                                                        <i data-feather="{{ $depoarrowIcon }}" class="icon-sm mb-1"></i>
                                                    </p>
                                                </div>
                                            </div>

                                            <script>
                                                document.addEventListener('DOMContentLoaded', function() {
                                                    if (window.feather) {
                                                        window.feather.replace();
                                                    }
                                                });
                                            </script>
                                            {{--                                        <div class="col-6 col-md-12 col-xl-7">--}}
                                            {{--                                            <div id="growthChart" class="mt-md-3 mt-xl-0"></div>--}}
                                            {{--                                        </div>--}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <!-- end section 2 -->
                        @endif
                    </div>
                </div>
            </div> <!-- row -->

            <!-- <div class="row">
              <div class="col-12 col-xl-12 grid-margin stretch-card">
                <div class="card overflow-hidden">
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-baseline mb-4 mb-md-3">
                      <h6 class="card-title mb-0">Revenue</h6>
                      <div class="dropdown">
                        <a type="button" id="dropdownMenuButton3" data-bs-toggle="dropdown" aria-haspopup="true"
                          aria-expanded="false">
                          <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton3">
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"
                              class="icon-sm me-2"></i> <span class="">View</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="edit-2"
                              class="icon-sm me-2"></i> <span class="">Edit</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"
                              class="icon-sm me-2"></i> <span class="">Delete</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="printer"
                              class="icon-sm me-2"></i> <span class="">Print</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="download"
                              class="icon-sm me-2"></i> <span class="">Download</span></a>
                        </div>
                      </div>
                    </div>
                    <div class="row align-items-start">
                      <div class="col-md-7">
                        <p class="text-muted tx-13 mb-3 mb-md-0">Revenue is the income that a business has from its normal
                          business activities, usually from the sale of goods and services to customers.</p>
                      </div>
                      <div class="col-md-5 d-flex justify-content-md-end">
                        <div class="btn-group mb-3 mb-md-0" role="group" aria-label="Basic example">
                          <button type="button" class="btn btn-outline-primary">Today</button>
                          <button type="button" class="btn btn-outline-primary d-none d-md-block">Week</button>
                          <button type="button" class="btn btn-primary">Month</button>
                          <button type="button" class="btn btn-outline-primary">Year</button>
                        </div>
                      </div>
                    </div>
                    <div id="revenueChart"></div>
                  </div>
                </div>
              </div>
            </div> -->

            <!-- <div class="row">
              <div class="col-lg-7 col-xl-8 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-baseline mb-2">
                      <h6 class="card-title mb-0">Monthly sales</h6>
                      <div class="dropdown mb-2">
                        <a type="button" id="dropdownMenuButton4" data-bs-toggle="dropdown" aria-haspopup="true"
                          aria-expanded="false">
                          <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton4">
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"
                              class="icon-sm me-2"></i> <span class="">View</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="edit-2"
                              class="icon-sm me-2"></i> <span class="">Edit</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"
                              class="icon-sm me-2"></i> <span class="">Delete</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="printer"
                              class="icon-sm me-2"></i> <span class="">Print</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="download"
                              class="icon-sm me-2"></i> <span class="">Download</span></a>
                        </div>
                      </div>
                    </div>
                    <p class="text-muted">Sales are activities related to selling or the number of goods or services sold in
                      a given time period.</p>
                    <div id="monthlySalesChart"></div>
                  </div>
                </div>
              </div>
              <div class="col-lg-5 col-xl-4 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-baseline">
                      <h6 class="card-title mb-0">Cloud storage</h6>
                      <div class="dropdown mb-2">
                        <a type="button" id="dropdownMenuButton5" data-bs-toggle="dropdown" aria-haspopup="true"
                          aria-expanded="false">
                          <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton5">
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"
                              class="icon-sm me-2"></i> <span class="">View</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="edit-2"
                              class="icon-sm me-2"></i> <span class="">Edit</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"
                              class="icon-sm me-2"></i> <span class="">Delete</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="printer"
                              class="icon-sm me-2"></i> <span class="">Print</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="download"
                              class="icon-sm me-2"></i> <span class="">Download</span></a>
                        </div>
                      </div>
                    </div>
                    <div id="storageChart"></div>
                    <div class="row mb-3">
                      <div class="col-6 d-flex justify-content-end">
                        <div>
                          <label class="d-flex align-items-center justify-content-end tx-10 text-uppercase fw-bolder">Total
                            storage <span class="p-1 ms-1 rounded-circle bg-secondary"></span></label>
                          <h5 class="fw-bolder mb-0 text-end">8TB</h5>
                        </div>
                      </div>
                      <div class="col-6">
                        <div>
                          <label class="d-flex align-items-center tx-10 text-uppercase fw-bolder"><span
                              class="p-1 me-1 rounded-circle bg-primary"></span> Used storage</label>
                          <h5 class="fw-bolder mb-0">~5TB</h5>
                        </div>
                      </div>
                    </div>
                    <div class="d-grid">
                      <button class="btn btn-primary">Upgrade storage</button>
                    </div>
                  </div>
                </div>
              </div>
            </div> -->

            <!-- <div class="row">
              <div class="col-lg-5 col-xl-4 grid-margin grid-margin-xl-0 stretch-card">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-baseline mb-2">
                      <h6 class="card-title mb-0">Inbox</h6>
                      <div class="dropdown mb-2">
                        <a type="button" id="dropdownMenuButton6" data-bs-toggle="dropdown" aria-haspopup="true"
                          aria-expanded="false">
                          <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton6">
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"
                              class="icon-sm me-2"></i> <span class="">View</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="edit-2"
                              class="icon-sm me-2"></i> <span class="">Edit</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"
                              class="icon-sm me-2"></i> <span class="">Delete</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="printer"
                              class="icon-sm me-2"></i> <span class="">Print</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="download"
                              class="icon-sm me-2"></i> <span class="">Download</span></a>
                        </div>
                      </div>
                    </div>
                    <div class="d-flex flex-column">
                      <a href="javascript:;" class="d-flex align-items-center border-bottom pb-3">
                        <div class="me-3">
                          <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-35" alt="user">
                        </div>
                        <div class="w-100">
                          <div class="d-flex justify-content-between">
                            <h6 class="text-body mb-2">Leonardo Payne</h6>
                            <p class="text-muted tx-12">12.30 PM</p>
                          </div>
                          <p class="text-muted tx-13">Hey! there I'm available...</p>
                        </div>
                      </a>
                      <a href="javascript:;" class="d-flex align-items-center border-bottom py-3">
                        <div class="me-3">
                          <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-35" alt="user">
                        </div>
                        <div class="w-100">
                          <div class="d-flex justify-content-between">
                            <h6 class="text-body mb-2">Carl Henson</h6>
                            <p class="text-muted tx-12">02.14 AM</p>
                          </div>
                          <p class="text-muted tx-13">I've finished it! See you so..</p>
                        </div>
                      </a>
                      <a href="javascript:;" class="d-flex align-items-center border-bottom py-3">
                        <div class="me-3">
                          <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-35" alt="user">
                        </div>
                        <div class="w-100">
                          <div class="d-flex justify-content-between">
                            <h6 class="text-body mb-2">Jensen Combs</h6>
                            <p class="text-muted tx-12">08.22 PM</p>
                          </div>
                          <p class="text-muted tx-13">This template is awesome!</p>
                        </div>
                      </a>
                      <a href="javascript:;" class="d-flex align-items-center border-bottom py-3">
                        <div class="me-3">
                          <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-35" alt="user">
                        </div>
                        <div class="w-100">
                          <div class="d-flex justify-content-between">
                            <h6 class="text-body mb-2">Amiah Burton</h6>
                            <p class="text-muted tx-12">05.49 AM</p>
                          </div>
                          <p class="text-muted tx-13">Nice to meet you</p>
                        </div>
                      </a>
                      <a href="javascript:;" class="d-flex align-items-center border-bottom py-3">
                        <div class="me-3">
                          <img src="https://via.placeholder.com/35x35" class="rounded-circle wd-35" alt="user">
                        </div>
                        <div class="w-100">
                          <div class="d-flex justify-content-between">
                            <h6 class="text-body mb-2">Yaretzi Mayo</h6>
                            <p class="text-muted tx-12">01.19 AM</p>
                          </div>
                          <p class="text-muted tx-13">Hey! there I'm available...</p>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-7 col-xl-8 stretch-card">
                <div class="card">
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-baseline mb-2">
                      <h6 class="card-title mb-0">Projects</h6>
                      <div class="dropdown mb-2">
                        <a type="button" id="dropdownMenuButton7" data-bs-toggle="dropdown" aria-haspopup="true"
                          aria-expanded="false">
                          <i class="icon-lg text-muted pb-3px" data-feather="more-horizontal"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton7">
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="eye"
                              class="icon-sm me-2"></i> <span class="">View</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="edit-2"
                              class="icon-sm me-2"></i> <span class="">Edit</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="trash"
                              class="icon-sm me-2"></i> <span class="">Delete</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="printer"
                              class="icon-sm me-2"></i> <span class="">Print</span></a>
                          <a class="dropdown-item d-flex align-items-center" href="javascript:;"><i data-feather="download"
                              class="icon-sm me-2"></i> <span class="">Download</span></a>
                        </div>
                      </div>
                    </div>
                    <div class="table-responsive">
                      <table class="table table-hover mb-0">
                        <thead>
                          <tr>
                            <th class="pt-0">#</th>
                            <th class="pt-0">Project Name</th>
                            <th class="pt-0">Start Date</th>
                            <th class="pt-0">Due Date</th>
                            <th class="pt-0">Status</th>
                            <th class="pt-0">Assign</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>1</td>
                            <td>NobleUI jQuery</td>
                            <td>01/01/2022</td>
                            <td>26/04/2022</td>
                            <td><span class="badge bg-danger">Released</span></td>
                            <td>Leonardo Payne</td>
                          </tr>
                          <tr>
                            <td>2</td>
                            <td>NobleUI Angular</td>
                            <td>01/01/2022</td>
                            <td>26/04/2022</td>
                            <td><span class="badge bg-success">Review</span></td>
                            <td>Carl Henson</td>
                          </tr>
                          <tr>
                            <td>3</td>
                            <td>NobleUI ReactJs</td>
                            <td>01/05/2022</td>
                            <td>10/09/2022</td>
                            <td><span class="badge bg-info">Pending</span></td>
                            <td>Jensen Combs</td>
                          </tr>
                          <tr>
                            <td>4</td>
                            <td>NobleUI VueJs</td>
                            <td>01/01/2022</td>
                            <td>31/11/2022</td>
                            <td><span class="badge bg-warning">Work in Progress</span>
                            </td>
                            <td>Amiah Burton</td>
                          </tr>
                          <tr>
                            <td>5</td>
                            <td>NobleUI Laravel</td>
                            <td>01/01/2022</td>
                            <td>31/12/2022</td>
                            <td><span class="badge bg-danger">Coming soon</span></td>
                            <td>Yaretzi Mayo</td>
                          </tr>
                          <tr>
                            <td>6</td>
                            <td>NobleUI NodeJs</td>
                            <td>01/01/2022</td>
                            <td>31/12/2022</td>
                            <td><span class="badge bg-primary">Coming soon</span></td>
                            <td>Carl Henson</td>
                          </tr>
                          <tr>
                            <td class="border-bottom">3</td>
                            <td class="border-bottom">NobleUI EmberJs</td>
                            <td class="border-bottom">01/05/2022</td>
                            <td class="border-bottom">10/11/2022</td>
                            <td class="border-bottom"><span class="badge bg-info">Pending</span></td>
                            <td class="border-bottom">Jensen Combs</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div> -->

        </div>

        <!-- partial:partials/_footer.html -->

        <!-- partial -->

    </div>

@endsection

<!-- core:js -->
